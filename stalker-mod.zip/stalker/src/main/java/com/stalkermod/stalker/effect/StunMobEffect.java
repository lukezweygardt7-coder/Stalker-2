package com.stalkermod.stalker.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Applied to the head hitbox by the Pistol. While active, the entity's
 * {@link com.stalkermod.stalker.entity.QuadrupedalStalkerEntity} suppresses
 * its goal selector (see entity tick) so the mob stands frozen.
 */
public class StunMobEffect extends MobEffect {

    public StunMobEffect() {
        super(MobEffectCategory.HARMFUL, 0x3a3a3a);
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return false;
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
        // No per-tick payload; the entity reads hasEffect(STUN) itself.
    }
}
