package com.stalkermod.stalker.item;

import net.minecraft.world.item.Item;

public class RifleBulletItem extends Item {
    public RifleBulletItem(Properties properties) {
        super(properties);
    }
}
