package com.stalkermod.stalker.item;

import com.stalkermod.stalker.entity.QuadrupedalStalkerEntity;
import com.stalkermod.stalker.registry.ModRegistry;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.function.Predicate;

public class PistolItem extends Item {

    private static final double RANGE = 48.0D;
    private static final float BODY_DAMAGE = 6.0F;
    private static final float HEADSHOT_DAMAGE = 10.0F;
    private static final int STUN_MIN_TICKS = 60;  // 3s
    private static final int STUN_MAX_TICKS = 100; // 5s

    public PistolItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        boolean creative = player.getAbilities().instabuild;
        if (!creative && !consumeAmmo(player, ModRegistry.BULLET.get())) {
            level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.6F, 1.6F);
            return InteractionResultHolder.fail(stack);
        }

        fireShot(level, player, stack, creative);
        return InteractionResultHolder.success(stack);
    }

    private void fireShot(Level level, Player player, ItemStack stack, boolean creative) {
        level.playSound(null, player.blockPosition(), ModRegistry.PISTOL_SHOT.get(), SoundSource.PLAYERS, 1.0F, 1.0F);

        Vec3 start = player.getEyePosition(1.0F);
        Vec3 look = player.getViewVector(1.0F);
        Vec3 end = start.add(look.scale(RANGE));

        EntityHitResult hit = pickEntity(level, player, start, end);
        if (hit == null) {
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
            return;
        }

        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity living)) return;

        boolean headshot = isHeadshot(living, hit.getLocation());

        if (living instanceof QuadrupedalStalkerEntity stalker) {
            living.hurt(level.damageSources().playerAttack(player), headshot ? HEADSHOT_DAMAGE : BODY_DAMAGE);
            if (headshot) {
                stalker.applyHeadshotStun(STUN_MIN_TICKS, STUN_MAX_TICKS);
            }
        } else {
            living.hurt(level.damageSources().playerAttack(player), headshot ? HEADSHOT_DAMAGE : BODY_DAMAGE);
        }

        stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
    }

    /** True when the hit point is in the top ~20% of the entity's bounding box (its head). */
    public static boolean isHeadshot(LivingEntity target, Vec3 hitPoint) {
        AABB box = target.getBoundingBox();
        double heightFraction = (hitPoint.y - box.minY) / Math.max(0.001, box.getYsize());
        return heightFraction >= 0.8;
    }

    public static EntityHitResult pickEntity(Level level, Player shooter, Vec3 start, Vec3 end) {
        AABB searchBox = shooter.getBoundingBox().expandTowards(end.subtract(start)).inflate(2.0D);
        Predicate<Entity> filter = e -> !e.isSpectator() && e.isPickable() && e != shooter;
        List<Entity> candidates = level.getEntities(shooter, searchBox, filter);

        Entity closest = null;
        double closestDistSq = Double.MAX_VALUE;
        Vec3 closestHit = null;

        for (Entity candidate : candidates) {
            AABB box = candidate.getBoundingBox().inflate(0.15D);
            var optHit = box.clip(start, end);
            if (optHit.isPresent()) {
                double distSq = start.distanceToSqr(optHit.get());
                if (distSq < closestDistSq) {
                    closestDistSq = distSq;
                    closest = candidate;
                    closestHit = optHit.get();
                }
            }
        }

        // Also check block occlusion; if a block is closer than the entity, no entity hit.
        var blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, shooter));
        if (blockHit.getType() == HitResult.Type.BLOCK) {
            double blockDistSq = start.distanceToSqr(blockHit.getLocation());
            if (blockDistSq < closestDistSq) return null;
        }

        return closest == null ? null : new EntityHitResult(closest, closestHit);
    }

    static boolean consumeAmmo(Player player, Item ammo) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(ammo)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }
}
