package com.stalkermod.stalker.item;

import com.stalkermod.stalker.entity.QuadrupedalStalkerEntity;
import com.stalkermod.stalker.registry.ModRegistry;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public class Ak47Item extends Item {

    private static final double RANGE = 56.0D;
    private static final float DAMAGE_PER_ROUND = 4.0F; // low per-shot, high RoF -> sustained fire required
    private static final int TICKS_BETWEEN_SHOTS = 3;   // ~6.6 rounds/sec at 20 TPS
    private static final float RECOIL_PITCH_PER_SHOT = 1.1F;
    private static final float MAX_USE_DURATION = 72000F;

    public Ak47Item(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;
        if (!creative && !PistolItem.consumeAmmo(player, ModRegistry.RIFLE_BULLET.get())) {
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity user, ItemStack stack, int remainingUseDuration) {
        if (level.isClientSide || !(user instanceof Player player)) return;

        int elapsed = (int) (getUseDuration(stack) - remainingUseDuration);
        if (elapsed % TICKS_BETWEEN_SHOTS != 0) return;

        boolean creative = player.getAbilities().instabuild;
        if (!creative && !PistolItem.consumeAmmo(player, ModRegistry.RIFLE_BULLET.get())) {
            player.stopUsingItem();
            return;
        }

        fireRound(level, player, stack, creative);
    }

    private void fireRound(Level level, Player player, ItemStack stack, boolean creative) {
        level.playSound(null, player.blockPosition(), ModRegistry.AK47_SHOT.get(), SoundSource.PLAYERS, 0.8F, 1.0F);

        // Simple recoil: nudge the player's pitch upward each round.
        player.setXRot(player.getXRot() - RECOIL_PITCH_PER_SHOT * (0.5F + level.random.nextFloat() * 0.5F));

        Vec3 start = player.getEyePosition(1.0F);
        Vec3 look = player.getViewVector(1.0F);
        Vec3 end = start.add(look.scale(RANGE));

        EntityHitResult hit = PistolItem.pickEntity(level, player, start, end);
        if (hit == null) {
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
            return;
        }

        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity living)) return;

        boolean headshot = PistolItem.isHeadshot(living, hit.getLocation());
        float damage = DAMAGE_PER_ROUND * (headshot ? 1.5F : 1.0F);
        living.hurt(level.damageSources().playerAttack(player), damage);

        if (living instanceof QuadrupedalStalkerEntity stalker && headshot) {
            // A single AK round only staggers, not stuns; the Pistol is the dedicated stun tool.
            stalker.setDeltaMovement(stalker.getDeltaMovement().multiply(0.2, 1, 0.2));
        }

        stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(player.getUsedItemHand()));
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return (int) MAX_USE_DURATION;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }
}
