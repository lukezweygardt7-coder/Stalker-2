package com.stalkermod.stalker.registry;

import com.stalkermod.stalker.StalkerMod;
import com.stalkermod.stalker.effect.StunMobEffect;
import com.stalkermod.stalker.entity.QuadrupedalStalkerEntity;
import com.stalkermod.stalker.item.Ak47Item;
import com.stalkermod.stalker.item.BulletItem;
import com.stalkermod.stalker.item.PistolItem;
import com.stalkermod.stalker.item.RifleBulletItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

public class ModRegistry {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, StalkerMod.MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, StalkerMod.MOD_ID);
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, StalkerMod.MOD_ID);
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, StalkerMod.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, StalkerMod.MOD_ID);

    // ---- Entity ----
    public static final RegistryObject<EntityType<QuadrupedalStalkerEntity>> QUADRUPEDAL_STALKER =
            ENTITIES.register("quadrupedal_stalker", () -> EntityType.Builder
                    .of(QuadrupedalStalkerEntity::new, MobCategory.MONSTER)
                    .sized(1.3f, 1.75f) // visual cutout model is taller/wider than the hitbox; that's fine
                    .clientTrackingRange(16)
                    .build("quadrupedal_stalker"));

    // ---- Effects ----
    public static final RegistryObject<MobEffect> STUN =
            EFFECTS.register("stun", StunMobEffect::new);

    // ---- Sounds ----
    public static final RegistryObject<SoundEvent> STALKER_GROWL =
            SOUNDS.register("stalker_growl", () -> SoundEvent.createVariableRangeEvent(
                    new ResourceLocation(StalkerMod.MOD_ID, "stalker_growl")));
    public static final RegistryObject<SoundEvent> STALKER_DOOR_BREAK =
            SOUNDS.register("stalker_door_break", () -> SoundEvent.createVariableRangeEvent(
                    new ResourceLocation(StalkerMod.MOD_ID, "stalker_door_break")));
    public static final RegistryObject<SoundEvent> PISTOL_SHOT =
            SOUNDS.register("pistol_shot", () -> SoundEvent.createVariableRangeEvent(
                    new ResourceLocation(StalkerMod.MOD_ID, "pistol_shot")));
    public static final RegistryObject<SoundEvent> AK47_SHOT =
            SOUNDS.register("ak47_shot", () -> SoundEvent.createVariableRangeEvent(
                    new ResourceLocation(StalkerMod.MOD_ID, "ak47_shot")));

    // ---- Ammo ----
    public static final RegistryObject<Item> BULLET =
            ITEMS.register("bullet", () -> new BulletItem(new Item.Properties().stacksTo(64)));
    public static final RegistryObject<Item> RIFLE_BULLET =
            ITEMS.register("rifle_bullet", () -> new RifleBulletItem(new Item.Properties().stacksTo(64)));

    // ---- Firearms ----
    public static final RegistryObject<Item> PISTOL =
            ITEMS.register("pistol", () -> new PistolItem(new Item.Properties().stacksTo(1).durability(200)));
    public static final RegistryObject<Item> AK47 =
            ITEMS.register("ak47", () -> new Ak47Item(new Item.Properties().stacksTo(1).durability(500)));

    // ---- Spawn egg (debug/testing convenience) ----
    public static final RegistryObject<Item> STALKER_SPAWN_EGG = ITEMS.register("quadrupedal_stalker_spawn_egg",
            () -> new net.minecraft.world.item.ForgeSpawnEggItem(QUADRUPEDAL_STALKER,
                    0x0d0d0d, 0x8a0000, new Item.Properties()));

    // ---- Creative tab ----
    public static final RegistryObject<CreativeModeTab> STALKER_TAB = CREATIVE_TABS.register("stalker_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.stalker"))
                    .icon(() -> new ItemStack(AK47.get()))
                    .displayItems((params, output) -> {
                        output.accept(PISTOL.get());
                        output.accept(AK47.get());
                        output.accept(BULLET.get());
                        output.accept(RIFLE_BULLET.get());
                        output.accept(STALKER_SPAWN_EGG.get());
                    })
                    .build());
}
