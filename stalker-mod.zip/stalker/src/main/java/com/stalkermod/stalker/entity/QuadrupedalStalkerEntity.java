package com.stalkermod.stalker.entity;

import com.stalkermod.stalker.registry.ModRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.entity.LivingEntity;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.EnumSet;

public class QuadrupedalStalkerEntity extends Monster implements GeoEntity {

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    private static final RawAnimation ANIM_IDLE = RawAnimation.begin().thenLoop("animation.stalker.idle");
    private static final RawAnimation ANIM_WALK = RawAnimation.begin().thenLoop("animation.stalker.walk");
    private static final RawAnimation ANIM_STALK = RawAnimation.begin().thenLoop("animation.stalker.stalk_freeze");
    private static final RawAnimation ANIM_ATTACK = RawAnimation.begin().thenPlay("animation.stalker.attack");
    private static final RawAnimation ANIM_DOOR_BREAK = RawAnimation.begin().thenPlay("animation.stalker.door_break");
    private static final RawAnimation ANIM_STUNNED = RawAnimation.begin().thenLoop("animation.stalker.stunned");
    private static final RawAnimation ANIM_DEATH = RawAnimation.begin().thenPlay("animation.stalker.death");

    /** True while the entity is frozen because the player is currently looking at it. */
    private boolean beingObserved = false;
    private int doorBreakCooldown = 0;

    public QuadrupedalStalkerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ARMOR, 4.0D);
    }

    public static boolean canSpawnHere(EntityType<QuadrupedalStalkerEntity> type, ServerLevelAccessor level,
                                        MobSpawnType reason, BlockPos pos, net.minecraft.util.RandomSource random) {
        return level.getDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                && level.getRawBrightness(pos, 0) <= 4
                && Monster.checkMonsterSpawnRules(type, level, reason, pos, random);
    }

    @Override
    protected void registerGoals() {
        // Highest priority: freeze or vanish while being looked at directly.
        this.goalSelector.addGoal(0, new FreezeWhenObservedGoal(this));

        this.goalSelector.addGoal(1, new BreakDoorGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3D, true));
        this.goalSelector.addGoal(3, new StalkAndApproachGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();

        boolean stunned = this.hasEffect(ModRegistry.STUN.get());
        this.getNavigation().setCanFloat(true);

        if (stunned) {
            this.getNavigation().stop();
            this.setDeltaMovement(this.getDeltaMovement().x * 0.1, this.getDeltaMovement().y, this.getDeltaMovement().z * 0.1);
            if (this.level() instanceof ServerLevel server && this.tickCount % 4 == 0) {
                server.sendParticles(ParticleTypes.CRIT, this.getX(), this.getEyeY(), this.getZ(), 2, 0.2, 0.2, 0.2, 0.01);
            }
        }

        if (this.doorBreakCooldown > 0) this.doorBreakCooldown--;
    }

    public boolean isStunned() {
        return this.hasEffect(ModRegistry.STUN.get());
    }

    public void applyHeadshotStun(int minTicks, int maxTicks) {
        int duration = minTicks + this.random.nextInt(Math.max(1, maxTicks - minTicks));
        this.addEffect(new MobEffectInstance(ModRegistry.STUN.get(), duration, 0, false, false, true));
        this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, 3, false, true, true));
        this.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, duration, 0, false, true, true));
        this.getNavigation().stop();
        if (this.getTarget() == null && this.level().getNearestPlayer(this, 24) != null) {
            this.setTarget(this.level().getNearestPlayer(this, 24));
        }
    }

    public boolean isObserved() {
        return this.beingObserved;
    }

    void setObserved(boolean observed) {
        this.beingObserved = observed;
    }

    public boolean canBreakDoors() {
        if (this.doorBreakCooldown > 0) return false;
        Level level = this.level();
        boolean storming = level.isRaining() || level.isThundering();
        boolean nightTime = level.isNight();
        return storming || nightTime;
    }

    public void startDoorBreakCooldown() {
        this.doorBreakCooldown = 100;
    }

    // ---------------- GeckoLib animation ----------------

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 4, this::movementPredicate));
        controllers.add(new AnimationController<>(this, "action", 0, this::actionPredicate));
    }

    private PlayState movementPredicate(AnimationState<QuadrupedalStalkerEntity> state) {
        if (!this.isAlive()) return state.setAndContinue(ANIM_DEATH);
        if (this.isStunned()) return state.setAndContinue(ANIM_STUNNED);
        if (this.isObserved()) return state.setAndContinue(ANIM_STALK);
        if (state.isMoving()) return state.setAndContinue(ANIM_WALK);
        return state.setAndContinue(ANIM_IDLE);
    }

    private PlayState actionPredicate(AnimationState<QuadrupedalStalkerEntity> state) {
        if (this.swinging) return state.setAndContinue(ANIM_ATTACK);
        return PlayState.STOP;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }

    // ---------------- Custom goals ----------------

    /** Weeping-Angel style: if a nearby player is looking directly at this entity, it freezes in place. */
    static class FreezeWhenObservedGoal extends Goal {
        private final QuadrupedalStalkerEntity stalker;

        FreezeWhenObservedGoal(QuadrupedalStalkerEntity stalker) {
            this.stalker = stalker;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            Player player = this.stalker.level().getNearestPlayer(this.stalker, 32);
            if (player == null || player.isSpectator()) {
                this.stalker.setObserved(false);
                return false;
            }
            boolean watched = isPlayerLookingAt(player, this.stalker);
            this.stalker.setObserved(watched);
            return watched && !this.stalker.isStunned();
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public void tick() {
            this.stalker.getNavigation().stop();
            this.stalker.setDeltaMovement(0, this.stalker.getDeltaMovement().y, 0);
        }

        @Override
        public void stop() {
            this.stalker.setObserved(false);
        }

        static boolean isPlayerLookingAt(Player player, LivingEntity target) {
            double dx = target.getX() - player.getX();
            double dy = target.getEyeY() - player.getEyeY();
            double dz = target.getZ() - player.getZ();
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist == 0) return false;
            dx /= dist; dy /= dist; dz /= dist;

            double yaw = Math.toRadians(player.getYRot() + 90);
            double pitch = Math.toRadians(-player.getXRot());
            double lx = Math.cos(pitch) * Math.cos(yaw);
            double ly = Math.sin(pitch);
            double lz = Math.cos(pitch) * Math.sin(yaw);

            double dot = lx * dx + ly * dy + lz * dz;
            boolean withinCone = dot > 0.92; // ~23 degree cone
            return withinCone && player.hasLineOfSight(target);
        }
    }

    /** Lurks at range, staying out of direct light/view, closing distance when unobserved. */
    static class StalkAndApproachGoal extends Goal {
        private final QuadrupedalStalkerEntity stalker;
        private Player target;

        StalkAndApproachGoal(QuadrupedalStalkerEntity stalker) {
            this.stalker = stalker;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.stalker.isStunned() || this.stalker.isObserved()) return false;
            this.target = this.stalker.level().getNearestPlayer(this.stalker, 40);
            return this.target != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && !this.stalker.isObserved() && !this.stalker.isStunned();
        }

        @Override
        public void tick() {
            if (this.target == null) return;
            double distSq = this.stalker.distanceToSqr(this.target);
            // Keep lurking at the edge of range unless night/storm aggression kicks in.
            boolean aggressive = this.stalker.canBreakDoors();
            double desired = aggressive ? 1.0D : 10.0D;
            if (distSq > desired * desired) {
                this.stalker.getNavigation().moveTo(this.target, aggressive ? 1.1D : 0.6D);
            } else if (!aggressive) {
                this.stalker.getNavigation().stop();
            }
            this.stalker.getLookControl().setLookAt(this.target, 30f, 30f);
        }
    }

    /** During storms/night, breaks wooden doors blocking the path to a cornered target. */
    static class BreakDoorGoal extends Goal {
        private final QuadrupedalStalkerEntity stalker;
        private BlockPos doorPos;
        private int breakProgress;

        BreakDoorGoal(QuadrupedalStalkerEntity stalker) {
            this.stalker = stalker;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!this.stalker.canBreakDoors() || this.stalker.isStunned()) return false;
            Player player = this.stalker.level().getNearestPlayer(this.stalker, 16);
            if (player == null) return false;
            this.doorPos = findBlockingDoor();
            return this.doorPos != null;
        }

        private BlockPos findBlockingDoor() {
            BlockPos origin = this.stalker.blockPosition();
            for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-2, -1, -2), origin.offset(2, 1, 2))) {
                BlockState state = this.stalker.level().getBlockState(pos);
                if (state.is(BlockTags.WOODEN_DOORS) && state.getBlock() instanceof DoorBlock) {
                    return pos.immutable();
                }
            }
            return null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.doorPos != null && this.stalker.canBreakDoors() && !this.stalker.isStunned();
        }

        @Override
        public void start() {
            this.breakProgress = 0;
        }

        @Override
        public void tick() {
            if (this.doorPos == null) return;
            this.stalker.getLookControl().setLookAt(this.doorPos.getX() + 0.5, this.doorPos.getY() + 0.5, this.doorPos.getZ() + 0.5);
            this.breakProgress++;
            if (this.breakProgress % 10 == 0) {
                this.stalker.level().playSound(null, this.doorPos, SoundEvents.WOOD_HIT, SoundSource.HOSTILE, 1.0F, 0.8F);
            }
            if (this.breakProgress >= 40) {
                BlockState state = this.stalker.level().getBlockState(this.doorPos);
                if (state.getBlock() instanceof DoorBlock) {
                    this.stalker.level().destroyBlock(this.doorPos, false, this.stalker);
                    this.stalker.level().playSound(null, this.doorPos, SoundEvents.WOODEN_DOOR_BREAK, SoundSource.HOSTILE, 1.0F, 0.9F);
                    this.stalker.startDoorBreakCooldown();
                }
                this.doorPos = null;
            }
        }
    }
}
