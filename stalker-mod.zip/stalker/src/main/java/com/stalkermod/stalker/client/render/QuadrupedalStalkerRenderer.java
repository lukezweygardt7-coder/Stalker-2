package com.stalkermod.stalker.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.stalkermod.stalker.client.model.QuadrupedalStalkerModel;
import com.stalkermod.stalker.entity.QuadrupedalStalkerEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class QuadrupedalStalkerRenderer extends GeoEntityRenderer<QuadrupedalStalkerEntity> {

    public QuadrupedalStalkerRenderer(EntityRendererProvider.Context context) {
        super(context, new QuadrupedalStalkerModel());
        this.shadowRadius = 0.6f;
    }

    @Override
    public void render(QuadrupedalStalkerEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                        MultiBufferSource bufferSource, int packedLight) {
        // Texture coordinates/UVs are owned entirely by the .geo.json (per-cube/mesh
        // "uv" entries) matched against the 1024x1024 albedo map — nothing here
        // touches UVs, which is what avoids stretching/z-fighting at render time.
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }
}
