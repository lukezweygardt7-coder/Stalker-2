package com.stalkermod.stalker;

import com.stalkermod.stalker.registry.ModRegistry;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import software.bernie.geckolib.GeckoLib;

@Mod(StalkerMod.MOD_ID)
public class StalkerMod {

    public static final String MOD_ID = "stalker";

    public StalkerMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModRegistry.ITEMS.register(modEventBus);
        ModRegistry.ENTITIES.register(modEventBus);
        ModRegistry.EFFECTS.register(modEventBus);
        ModRegistry.SOUNDS.register(modEventBus);
        ModRegistry.CREATIVE_TABS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);
        modEventBus.addListener(this::onEntityAttributeCreate);

        MinecraftForge.EVENT_BUS.register(this);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        GeckoLib.initialize();
    }

    private void onEntityAttributeCreate(final EntityAttributeCreationEvent event) {
        event.put(ModRegistry.QUADRUPEDAL_STALKER.get(),
                com.stalkermod.stalker.entity.QuadrupedalStalkerEntity.createAttributes().build());
        SpawnPlacements.register(ModRegistry.QUADRUPEDAL_STALKER.get(),
                SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                com.stalkermod.stalker.entity.QuadrupedalStalkerEntity::canSpawnHere);
    }
}
