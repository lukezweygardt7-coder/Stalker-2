package com.stalkermod.stalker.client.model;

import com.stalkermod.stalker.StalkerMod;
import com.stalkermod.stalker.entity.QuadrupedalStalkerEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class QuadrupedalStalkerModel extends GeoModel<QuadrupedalStalkerEntity> {

    // These three paths are the ONLY place the asset filenames are defined.
    // Match them exactly to whatever you export from Blockbench.
    @Override
    public ResourceLocation getModelResource(QuadrupedalStalkerEntity animatable) {
        return new ResourceLocation(StalkerMod.MOD_ID, "geo/quadrupedal_stalker.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(QuadrupedalStalkerEntity animatable) {
        return new ResourceLocation(StalkerMod.MOD_ID, "textures/entity/quadrupedal_stalker/atlas.png");
    }

    @Override
    public ResourceLocation getAnimationResource(QuadrupedalStalkerEntity animatable) {
        return new ResourceLocation(StalkerMod.MOD_ID, "animations/quadrupedal_stalker.animation.json");
    }
}
