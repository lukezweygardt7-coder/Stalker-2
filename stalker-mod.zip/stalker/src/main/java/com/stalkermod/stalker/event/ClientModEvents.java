package com.stalkermod.stalker.event;

import com.stalkermod.stalker.StalkerMod;
import com.stalkermod.stalker.client.render.QuadrupedalStalkerRenderer;
import com.stalkermod.stalker.registry.ModRegistry;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = StalkerMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModRegistry.QUADRUPEDAL_STALKER.get(), QuadrupedalStalkerRenderer::new);
    }
}
