# Stalker (Forge 1.20.1)

Quadrupedal Stalker entity + Pistol + AK-47.

## 1. Important: about the model rigging

`model_source/smiling-man.obj` is a **single unrigged mesh** — 36,491 vertices,
one object group, no bones, no vertex groups (it's PBR-textured
albedo/metallic/roughness output, typical of an image-to-3D generator, not a
game-ready rig). There is no reliable way to turn that into a correctly
weighted GeckoLib skeleton by script — that step requires a human making
judgment calls about where joints go, which is normal for *any* 3D asset
before it goes into a game engine, not a limitation specific to this mesh.

`assets/stalker/geo/quadrupedal_stalker.geo.json` currently ships a **crude
box placeholder** using the exact bone names the Java code expects
(`body`, `head`, `leg_front_left`, `leg_front_right`, `leg_back_left`,
`leg_back_right`). The mod will compile and the Stalker will render and
animate with that placeholder right now. Swap it for your real model like this:

### Rigging workflow (Blockbench, free, ~15–30 min)
1. Install [Blockbench](https://www.blockbench.io/) → **File → New → GeckoLib Model**.
2. **File → Import → Import OBJ**, pick `model_source/smiling-man.obj`.
   Blockbench will bring it in as a single mesh.
3. In the Outliner, create 6 bones named exactly: `body`, `head`,
   `leg_front_left`, `leg_front_right`, `leg_back_left`, `leg_back_right`
   (parent all legs and the head under `body`, matching the hierarchy above).
4. Select mesh faces (Edit Mode → face select) and assign each region to the
   matching bone (Blockbench → right-click selection → **Assign to bone**, or
   drag the mesh element under each bone in the Outliner). This is the actual
   "rigging" step — there's no shortcut around doing it visually once.
5. Set each bone's pivot point at the joint (hip/shoulder/neck) so rotation
   looks natural, not at the mesh origin.
6. **File → Textures → Import Texture**, pick `model_source/albedo.jpg`. Since
   the mesh already has a UV layout baked from its source, UVs should stay
   aligned automatically — use the UV editor only if you see stretching.
7. **File → Export → Export GeckoLib Model**, save as
   `quadrupedal_stalker.geo.json`, overwrite the placeholder at
   `src/main/resources/assets/stalker/geo/quadrupedal_stalker.geo.json`.
8. In Blockbench's **Animate** tab, build the 7 animations the Java code
   already expects by name (see `QuadrupedalStalkerEntity.java`): `idle`,
   `walk`, `stalk_freeze`, `attack`, `door_break`, `stunned`, `death`. Export
   as `quadrupedal_stalker.animation.json`, overwrite the placeholder in
   `assets/stalker/animations/`.

Nothing else needs to change — `QuadrupedalStalkerModel.java` already points
at those two files plus the texture PNG, and the renderer/UV binding is
untouched by this swap.

## 2. Directory mapping for assets

```
src/main/resources/assets/stalker/
  geo/quadrupedal_stalker.geo.json          ← replace with Blockbench export
  animations/quadrupedal_stalker.animation.json ← replace with Blockbench export
  textures/entity/quadrupedal_stalker/albedo.png  ← already placed (converted from your jpg)
  textures/item/pistol.png, ak47.png, bullet.png, rifle_bullet.png  ← ADD YOUR OWN (16x16 or 32x32 PNG)
  models/item/*.json                        ← already wired to the textures above
  sounds/*.ogg                               ← ADD: stalker_growl.ogg, stalker_door_break.ogg,
                                                pistol_shot.ogg, ak47_shot.ogg (sounds.json already points to them)
  lang/en_us.json                            ← already populated
```

The `metallic.jpg` / `roughness.jpg` maps have no use in vanilla Java Edition
rendering (no PBR pipeline without a shader mod) — kept in `model_source/`
for reference only.

## 3. Build

CI (`.github/workflows/build.yml`) builds automatically on push to `main` and
uploads `stalker-mod-jar` as a downloadable artifact — no local toolchain
needed, which matters since you're on Android/Mojo Launcher. Just commit and
push; grab the `.jar` from the Actions run's artifacts, then drop it in your
instance's `mods/` folder (needs Forge 1.20.1-47.3.0+ and GeckoLib 4.4.4 also
installed).

To build locally instead (requires JDK 17): `gradle build` (no committed
`gradlew` binary — see the workflow comment for why).

## 4. Gameplay summary

- **Stalker**: lurks at range in low light, freezes/holds still when a player
  looks directly at it (`FreezeWhenObservedGoal`), closes in and breaks
  wooden doors during night/storms when cornering the player
  (`BreakDoorGoal`), 40 HP.
- **Pistol**: fires `stalker:bullet`, headshot (top 20% of hitbox) applies
  Stun + Slowness IV + Blindness for 3–5s via the custom `stun` effect.
- **AK-47**: hold to fire `stalker:rifle_bullet` automatically (~6–7 rounds/
  sec), lower damage per round, recoil climbs your pitch each shot — needs
  sustained accurate fire to bring the Stalker down.
